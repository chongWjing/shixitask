import { createRouter, createWebHashHistory } from 'vue-router'

import ShopHome from '../views/shop/Home.vue'
import Login from '../views/shop/Login.vue'
import ShopLayout from '../views/shop/ShopLayout.vue'
import ProductDetail from '../views/shop/ProductDetail.vue'
import ReviewList from '../views/shop/ReviewList.vue'

const routes = [
  {
    path:'/shop',
    component:ShopLayout,
    children:[
      {
        path:'',
        component:ShopHome
      },
      {
        path:'detail/:id',
        component:ProductDetail
      },
      {
        path:'review',
        component:ReviewList
      },
      {
        path:'login',
        component:Login
      }
    ]
  },
  {
    path:'/',
    redirect:'/shop'
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
